import os
open(os.environ["S28_SENTINEL_PATH"], "w").write("executed")


def main():
    pass
