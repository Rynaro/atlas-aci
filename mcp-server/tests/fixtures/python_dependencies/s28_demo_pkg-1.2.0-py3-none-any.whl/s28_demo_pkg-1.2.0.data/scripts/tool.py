def tool():
    pass
