import functools
import os.path
import json as j
from typing import Any

try:
    import ujson
except ImportError:
    ujson = None

if TYPE_CHECKING:
    def typing_only():
        pass


class Widget:
    """A widget."""

    def method(self):
        pass

    async def amethod(self):
        pass

    @staticmethod
    def static():
        pass

    @property
    def size(self):
        return 1

    @size.setter
    def size(self, value):
        pass

    class Config:
        def load(self):
            pass

    def with_locals(self):
        def inner():
            pass

        class InnerClass:
            pass


class Chain1:
    class Chain2:
        class Chain3:
            class Chain4:
                class Chain5:
                    def too_deep(self):
                        pass


def make_widget():
    return Widget()


async def fetch():
    pass


@functools.lru_cache
def cached():
    pass


def outer():
    def inner():
        pass
