def bad():
    pass
