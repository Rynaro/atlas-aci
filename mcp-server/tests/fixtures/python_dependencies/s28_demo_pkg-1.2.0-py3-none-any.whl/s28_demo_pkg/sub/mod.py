def __getattr__(name):
    raise AttributeError(name)

__all__ = ["a"] + extra
