"""Demo package: this module body has side effects that must never run."""
import os
import pathlib

_target = os.environ.get("S28_SENTINEL_PATH")
if _target:
    pathlib.Path(_target).write_text("executed")
os.system(":")

__all__ = ["Widget", "make_widget"]

from .core import Widget, make_widget
from . import helpers as h
raise RuntimeError("the s28 demo package must never be imported")
