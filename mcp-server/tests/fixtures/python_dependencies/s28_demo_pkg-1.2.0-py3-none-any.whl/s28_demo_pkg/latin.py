# caf�
def latin():
    pass
