class Phantom:
    def broken(self
