set -euo pipefail
# The image's reader principal can traverse its private snapshot
# objects; the runner UID cannot. Keep permissions intact and fail
# closed rather than accepting a partial host-side inventory.
cat > /private/tmp/aci-s08-ci-smoke-atvztacx/inventory.py <<'PY'
import hashlib
import json
import os
from pathlib import Path
import stat
import sys

assert os.geteuid() == 10001
root = Path(sys.argv[1])
rows = []

def visit(path):
    info = path.lstat()
    row = {
        "path": str(path.relative_to(root)),
        "mode": info.st_mode,
        "uid": info.st_uid,
        "gid": info.st_gid,
        "size": info.st_size,
        "mtime_ns": info.st_mtime_ns,
    }
    if stat.S_ISDIR(info.st_mode):
        row.update(type="directory", sha256=None)
        rows.append(row)
        with os.scandir(path) as entries:
            children = sorted((Path(e.path) for e in entries))
        for child in children:
            visit(child)
    elif stat.S_ISREG(info.st_mode):
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, "rb") as stream:
            assert os.fstat(stream.fileno()) == info
            row.update(type="file", sha256=hashlib.file_digest(stream, "sha256").hexdigest())
        rows.append(row)
    else:
        raise ValueError("Unexpected generated inventory entry: " + str(path))

assert root.is_dir() and not root.is_symlink()
visit(root)
# Emit nothing until every directory and file has been inspected.
print(json.dumps(sorted(rows, key=lambda r: r["path"]), sort_keys=True))
PY
docker run --rm --read-only --network none \
  -v /private/tmp/aci-s08-ci-smoke-atvztacx/repo:/repo:ro \
  -v /private/tmp/aci-s08-ci-smoke-atvztacx/inventory.py:/inventory.py:ro \
  --entrypoint python atlas-aci-s08-footprint /inventory.py /repo/.atlas \
  > /private/tmp/aci-s08-ci-smoke-atvztacx/before.json
cat /private/tmp/aci-s08-ci-smoke-atvztacx/before.json

