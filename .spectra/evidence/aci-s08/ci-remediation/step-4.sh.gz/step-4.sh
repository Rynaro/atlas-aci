set -euo pipefail
docker run --rm --read-only --network none \
  -v /private/tmp/aci-s08-ci-smoke-atvztacx/repo:/repo:ro \
  -v /private/tmp/aci-s08-ci-smoke-atvztacx/inventory.py:/inventory.py:ro \
  --entrypoint python atlas-aci-s08-footprint /inventory.py /repo/.atlas \
  > /private/tmp/aci-s08-ci-smoke-atvztacx/after.json
if ! diff -u /private/tmp/aci-s08-ci-smoke-atvztacx/before.json /private/tmp/aci-s08-ci-smoke-atvztacx/after.json; then
  echo "FAIL (AC-H-16): .atlas contents changed under a read-only serve mount"
  exit 1
fi
echo "Zero writes under .atlas confirmed."

