set -euo pipefail
mkdir -p /private/tmp/aci-s08-ci-smoke-atvztacx/repo/app
cat > /private/tmp/aci-s08-ci-smoke-atvztacx/repo/app/hello.rb <<'RUBY'
class Hello
  def call
  end
end
RUBY
# Permissive so the container's non-default UID (10001) can write
# regardless of the runner's own UID — a CI-only convenience, not
# a production security posture.
chmod -R 777 /private/tmp/aci-s08-ci-smoke-atvztacx/repo
docker run --rm -v /private/tmp/aci-s08-ci-smoke-atvztacx/repo:/repo atlas-aci-s08-footprint index --repo /repo

