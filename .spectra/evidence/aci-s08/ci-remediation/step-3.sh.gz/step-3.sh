set -euo pipefail
docker volume create aci-s08-ci-memex-e751d8de70e2 >/dev/null

# An MCP stdio server blocks reading its next request; hold stdin
# open via a FIFO so it doesn't see EOF and exit cleanly (which
# would be indistinguishable here from "crashed").
rm -f /private/tmp/aci-s08-ci-smoke-atvztacx/mcp-in
mkfifo /private/tmp/aci-s08-ci-smoke-atvztacx/mcp-in
exec 3<>/private/tmp/aci-s08-ci-smoke-atvztacx/mcp-in

docker run --rm -i --name aci-s08-ci-explicit-e751d8de70e2 --read-only \
  -v /private/tmp/aci-s08-ci-smoke-atvztacx/repo:/repo:ro \
  -v aci-s08-ci-memex-e751d8de70e2:/memex \
  atlas-aci-s08-footprint serve --repo /repo --memex-root /memex \
  <&3 > /private/tmp/aci-s08-ci-smoke-atvztacx/serve.log 2>&1 &

sleep 3

if ! docker ps --filter "name=aci-s08-ci-explicit-e751d8de70e2" --format '{{.Names}}' | grep -q aci-s08-ci-explicit-e751d8de70e2; then
  echo "FAIL (AC-H-16): serve did not stay alive under --read-only :ro"
  cat /private/tmp/aci-s08-ci-smoke-atvztacx/serve.log
  exit 1
fi
echo "serve stayed alive under --read-only :ro (expected)."
cat /private/tmp/aci-s08-ci-smoke-atvztacx/serve.log

docker kill aci-s08-ci-explicit-e751d8de70e2 >/dev/null 2>&1 || true
exec 3>&-
rm -f /private/tmp/aci-s08-ci-smoke-atvztacx/mcp-in

