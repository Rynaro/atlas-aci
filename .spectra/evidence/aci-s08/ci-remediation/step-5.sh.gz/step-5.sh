set -euo pipefail
# The step above uses the *documented* invocation (an explicit
# --memex-root on its own writable volume, matching the
# Dockerfile's baked CMD) and would pass even without the fix
# below. This step is the actual regression test: the default
# --memex-root (`<repo>/.atlas/memex`, INSIDE the read-only
# mount, no separate volume) is what a Docker smoke test caught
# crashing the whole server at startup (`Config.__post_init__` /
# `Memex.__init__` unconditionally calling `mkdir` — fixed to be
# best-effort). Must still start; `memex_read` degrading to
# NOT_FOUND for this session is an acceptable, documented
# consequence, not a crash.
rm -f /private/tmp/aci-s08-ci-smoke-atvztacx/mcp-in
mkfifo /private/tmp/aci-s08-ci-smoke-atvztacx/mcp-in
exec 3<>/private/tmp/aci-s08-ci-smoke-atvztacx/mcp-in

docker run --rm -i --name aci-s08-ci-nomemex-e751d8de70e2 --read-only \
  -v /private/tmp/aci-s08-ci-smoke-atvztacx/repo:/repo:ro \
  atlas-aci-s08-footprint serve --repo /repo \
  <&3 > /private/tmp/aci-s08-ci-smoke-atvztacx/serve-nomemex.log 2>&1 &

sleep 3

if ! docker ps --filter "name=aci-s08-ci-nomemex-e751d8de70e2" --format '{{.Names}}' | grep -q aci-s08-ci-nomemex-e751d8de70e2; then
  echo "FAIL: serve crashed without an explicit --memex-root under --read-only :ro"
  cat /private/tmp/aci-s08-ci-smoke-atvztacx/serve-nomemex.log
  exit 1
fi
echo "serve stayed alive without --memex-root under --read-only :ro (expected)."
cat /private/tmp/aci-s08-ci-smoke-atvztacx/serve-nomemex.log

docker kill aci-s08-ci-nomemex-e751d8de70e2 >/dev/null 2>&1 || true
exec 3>&-
rm -f /private/tmp/aci-s08-ci-smoke-atvztacx/mcp-in

