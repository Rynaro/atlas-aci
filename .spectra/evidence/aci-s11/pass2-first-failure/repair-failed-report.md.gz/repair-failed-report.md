# repair-failed-report → VIGIL (forensic-then-fix)

- outcome: capped
- reason: bounded retry budget exhausted on the same category
- attempts: 1 / 1
- pass^k: k=2
- tests: `mcp-server/.venv/bin/python -m pytest -q -p no:cacheprovider mcp-server/tests/slices/test_s11_protocol.py mcp-server/tests/slices/test_s11_contract.py mcp-server/tests/slices/test_s11_stdio.py mcp-server/tests/slices/test_s11_docker.py`
- protected (anchoring) tests: `mcp-server/tests/slices/test_s11_*.py`
- sealed holdout: `<none>`
- isolation tier: none
- base: 138a6f3cd510e0ecb3be0832221236adfe441ebc
- candidate diff: /tmp/aci-s11-pass2/candidate.diff (NOT applied/merged)
- structured feedback: /tmp/aci-s11-pass2/feedback.json (loop_contract)

## last test output (localized; full log: /tmp/aci-s11-pass2/full-log.txt)
```
                        assert "".join(json.loads(viewed.content[0].text)["lines"]) == source.decode()
                        assert (
                            json.loads(legacy.content[0].text)["generation_id"]
                            == payload["generation_id"]
                        )
                        assert len(json.loads(legacy.content[0].text)["edges"]) == 1
                        bad = await session.call_tool("graph_query", {"query": "invalid"})
                        assert bad.isError
                        record["negotiated_version"] = initialized.protocolVersion
                        record["results"] = [
                            r.model_dump(mode="json", exclude_none=True)
                            for r in (status, viewed, legacy, bad)
                        ]
                        record["result_byte_lengths"] = [
                            len(result_bytes(r)) for r in (status, viewed, legacy, bad)
                        ]
    
        try:
            asyncio.run(exercise())
        finally:
            subprocess.run(["docker", "rm", "-f", name], capture_output=True, timeout=30)
        after = json.loads(run([*mounts, "--entrypoint", "python", image, "-c", INVENTORY]))
>       assert before == after
E       AssertionError: assert {'entries': {... 'uid': 10001} == {'entries': {... 'uid': 10001}
E         
E         Omitting 2 identical items, use -vv to show
E         Differing items:
E         {'entries': {'/graphs': {'gid': 10001, 'mode': 16895, 'mtime_ns': 1792880139876430027, 'sha256': None, ...}, '/graphs/...ime_ns': 1792880139877241282, 'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', ...}, ...}} != {'entries': {'/graphs': {'gid': 10001, 'mode': 16895, 'mtime_ns': 1792880139876430027, 'sha256': None, ...}, '/graphs/...ime_ns': 1792880139877241282, 'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', ...}, ...}}
E         Use -v to get more diff

mcp-server/tests/slices/test_s11_docker.py:172: AssertionError
----------------------------- Captured stderr call -----------------------------
2026-10-24T22:15:40.385023Z [info     ] server_starting                memex=/memex repo=/repo
2026-10-24T22:15:40.399159Z [info     ] tool_call                      args={'schema_version': 'atlas.graph.v1', 'op': 'status'} bytes_out=7329 error=None ms=0 overflow=False tool=graph_query
2026-10-24T22:15:40.480387Z [info     ] tool_call                      args={'path': 'a.py', 'start_line': 1, 'end_line': 4, 'snapshot_id': '8c5722ff9e7dfb3c34e1fc83107e44a339e8a8a33b789b9970fe907f178dd1c2', 'source_sha256': '2d8dc49249e13bf4e3ef5afd052c3ca0da9ad4692517dd74ceaa23a67fa22041'} bytes_out=48 error=None ms=0 overflow=False tool=view_file
2026-10-24T22:15:40.486957Z [info     ] tool_call                      args={'query': 'callers_of:target'} bytes_out=235 error=None ms=0 overflow=False tool=graph_query
2026-10-24T22:15:40.526705Z [info     ] tool_call                      args={'query': 'invalid'} bytes_out=71 error=None ms=0 overflow=False tool=graph_query
=========================== short test summary info ============================
FAILED mcp-server/tests/slices/test_s11_docker.py::test_offline_readonly_status_and_legacy
1 failed, 41 passed in 4.47s
```

→ Hand off to VIGIL: reproduction-gated, counterfactual-verified root-cause attribution.
  The coder exhausted its bounded budget; bounded retry budget exhausted on the same category.
